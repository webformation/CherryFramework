<?php
$defaultText = __("Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam eu hendrerit nunc. Proin tempus pulvinar augue, quis ultrices urna consectetur non.", 'motopress-content-editor-lite');

$landingContent = <<<CONTENT
[mp_row]

[mp_span col="12"]

[mp_image size="full" link_type="custom_url" link="#" target="false" align="left" margin="none,10,none,none"]

[/mp_span]

[/mp_row]

[mp_row]

[mp_span col="4"]

[mp_row_inner]

[mp_span_inner col="12"]

[mp_image size="full" link_type="custom_url" link="#" target="false" align="left"]

[/mp_span_inner]

[/mp_row_inner]

[mp_row_inner]

[mp_span_inner col="12"]

[mp_text]
{$defaultText}
[/mp_text]

[/mp_span_inner]

[/mp_row_inner]

[/mp_span]

[mp_span col="4"]

[mp_row_inner]

[mp_span_inner col="12"]

[mp_image size="full" link_type="custom_url" link="#" target="false" align="left"]

[/mp_span_inner]

[/mp_row_inner]

[mp_row_inner]

[mp_span_inner col="12"]

[mp_text]
{$defaultText}
[/mp_text]

[/mp_span_inner]

[/mp_row_inner]

[/mp_span]

[mp_span col="4"]

[mp_row_inner]

[mp_span_inner col="12"]

[mp_image size="full" link_type="custom_url" link="#" target="false" align="left"]

[/mp_span_inner]

[/mp_row_inner]

[mp_row_inner]

[mp_span_inner col="12"]

[mp_text]
{$defaultText}
[/mp_text]

[/mp_span_inner]

[/mp_row_inner]

[/mp_span]

[/mp_row]

[mp_row]

[mp_span col="4"]

[mp_row_inner]

[mp_span_inner col="12"]

[mp_image size="full" link_type="custom_url" link="#" target="false" align="left"]

[/mp_span_inner]

[/mp_row_inner]

[mp_row_inner]

[mp_span_inner col="12"]

[mp_text]
{$defaultText}
[/mp_text]

[/mp_span_inner]

[/mp_row_inner]

[/mp_span]

[mp_span col="4"]

[mp_row_inner]

[mp_span_inner col="12"]

[mp_image size="full" link_type="custom_url" link="#" target="false" align="left"]

[/mp_span_inner]

[/mp_row_inner]

[mp_row_inner]

[mp_span_inner col="12"]

[mp_text]
{$defaultText}
[/mp_text]

[/mp_span_inner]

[/mp_row_inner]

[/mp_span]

[mp_span col="4"]

[mp_row_inner]

[mp_span_inner col="12"]

[mp_image size="full" link_type="custom_url" link="#" target="false" align="left"]

[/mp_span_inner]

[/mp_row_inner]

[mp_row_inner]

[mp_span_inner col="12"]

[mp_text]
{$defaultText}
[/mp_text]

[/mp_span_inner]

[/mp_row_inner]

[/mp_span]

[/mp_row]
CONTENT;

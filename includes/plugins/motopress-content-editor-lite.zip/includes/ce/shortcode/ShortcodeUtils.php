<?php

class MPCEShortcodeUtils {}